-- Conéctate al servidor de PostgreSQL y luego ejecuta:
CREATE DATABASE gestion_vehicular;

-- Conectar a la base de datos recién creada:
-- \c gestion_vehicular;
