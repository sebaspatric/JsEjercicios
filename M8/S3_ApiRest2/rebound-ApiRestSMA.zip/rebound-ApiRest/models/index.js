let listaLibros = [
    {
        titulo: "El Quijote de la Mancha",
        autor: "Miguel de Cervantes",
        isbn: "978-84-376-0515-5"
    },
    {
        titulo: "La Divina Comedia",
        autor: "J.uan XXIII",
        isbn: "978-0-7432-7554-6"
    }
];
export default {
    listaLibros
};

