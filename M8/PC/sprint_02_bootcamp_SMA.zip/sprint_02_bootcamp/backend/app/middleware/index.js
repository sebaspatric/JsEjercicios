const auth = require('./auth');
const verifySignUp = require('./verifySignUp');

module.exports = {
  auth,
  verifySignUp,
};
