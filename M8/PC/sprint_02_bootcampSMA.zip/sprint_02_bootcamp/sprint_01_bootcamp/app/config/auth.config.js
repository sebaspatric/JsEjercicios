module.exports = {
    secret: "mi_clave_secreta",
  };
  